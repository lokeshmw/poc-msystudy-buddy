from django.contrib import admin
from .models import ROOM, Topic, Message
# Register your models here.

admin.site.register(ROOM)
admin.site.register(Topic)
admin.site.register(Message)